package com.nxf.legacybridge;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int PICK_APK = 4101;
    private static final int BG = Color.rgb(7, 8, 18);
    private static final int PANEL = Color.rgb(19, 17, 38);
    private static final int PURPLE = Color.rgb(176, 92, 255);
    private static final int WHITE = Color.rgb(245, 242, 255);
    private static final int MUTED = Color.rgb(180, 174, 202);
    private LinearLayout content;
    private TextView apkReport;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(24), dp(18), dp(28));
        scroll.addView(content);

        TextView brand = text("NxF  LEGACY BRIDGE", 25, PURPLE, true);
        content.addView(brand);
        TextView subtitle = text("ANDROID COMPATIBILITY ASSISTANT", 11, MUTED, true);
        subtitle.setPadding(0, dp(5), 0, dp(18));
        content.addView(subtitle);

        addCard("DEVICE OVERVIEW",
                "Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n" +
                "Device: " + Build.MANUFACTURER + " " + Build.MODEL + "\n" +
                "CPU architecture: " + getAbiList() + "\n" +
                "Wireless debugging: " + (Build.VERSION.SDK_INT >= 30 ? "Supported by Android" : "Not available on this Android version"));

        addCard("SHIZUKU / ADB STATUS", shizukuGuidance());
        Button openShizuku = button("OPEN SHIZUKU");
        openShizuku.setOnClickListener(v -> openShizuku());
        content.addView(openShizuku);

        Button pick = button("CHECK AN APK FILE");
        pick.setOnClickListener(v -> pickApk());
        content.addView(pick);

        apkReport = text("No APK selected yet. Choose an APK file to inspect its declared Android requirements.", 13, MUTED, false);
        apkReport.setPadding(dp(14), dp(12), dp(14), dp(12));
        content.addView(apkReport);

        addCard("WHAT THIS APP CAN AND CANNOT DO",
                "✓ Check Android version and CPU architecture\n" +
                "✓ Read an APK's declared minimum Android version when available\n" +
                "✓ Open Android's official package installer\n" +
                "✓ Guide you to the correct Shizuku startup method\n\n" +
                "✕ Cannot add missing Android APIs or GPU features\n" +
                "✕ Cannot make an incompatible game run\n" +
                "✕ Does not bypass app security or compatibility checks");

        TextView footer = text("NxF • LEGACY BRIDGE V1.0 • LOCAL DIAGNOSTICS", 10, MUTED, true);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(20), 0, 0);
        content.addView(footer);

        setContentView(scroll);
    }

    private String shizukuGuidance() {
        if (Build.VERSION.SDK_INT < 23) {
            return "This device is Android 5.1 or older API level 22.\n" +
                    "Shizuku requires Android 6.0 or newer, so it cannot run here.\n" +
                    "NxF diagnostics and APK inspection can still work.";
        } else if (Build.VERSION.SDK_INT < 30) {
            return "Shizuku can be started on supported Android 6–10 devices using ADB from a computer.\n" +
                    "Modern Wireless Debugging pairing is not available on this Android version.";
        } else {
            return "This Android version supports Wireless Debugging (Android 11+).\n" +
                    "Install and start the official Shizuku app, pair it from Developer options, then start its service.\n" +
                    "NxF does not collect or store your pairing code.";
        }
    }

    private void openShizuku() {
        if (Build.VERSION.SDK_INT < 23) {
            toast("Shizuku requires Android 6.0 or newer.");
            return;
        }
        Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
        if (launch == null) {
            toast("Shizuku is not installed. Install it from its official project page.");
            return;
        }
        try {
            startActivity(launch);
        } catch (Exception e) {
            toast("Could not open Shizuku.");
        }
    }

    private void pickApk() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/vnd.android.package-archive");
        try {
            startActivityForResult(intent, PICK_APK);
        } catch (Exception e) {
            toast("No file picker is available on this device.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_APK || resultCode != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        inspectApk(uri);
    }

    private void inspectApk(Uri uri) {
        File temp = null;
        try {
            temp = File.createTempFile("nxf_apk_check_", ".apk", getCacheDir());
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(temp)) {
                if (in == null) throw new IllegalStateException("Cannot read selected file");
                byte[] buffer = new byte[8192];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            }

            PackageInfo info = getPackageManager().getPackageArchiveInfo(temp.getAbsolutePath(), PackageManager.GET_META_DATA);
            if (info == null || info.applicationInfo == null) {
                apkReport.setText("This file does not appear to be a valid APK.");
                return;
            }

            String minSdk = "Not exposed by this Android version";
            if (Build.VERSION.SDK_INT >= 24) {
                minSdk = String.valueOf(info.applicationInfo.minSdkVersion);
            }
            String packageName = info.packageName == null ? "Unknown" : info.packageName;
            String appName = packageName;
            if (info.applicationInfo != null) {
                info.applicationInfo.sourceDir = temp.getAbsolutePath();
                info.applicationInfo.publicSourceDir = temp.getAbsolutePath();
                CharSequence label = getPackageManager().getApplicationLabel(info.applicationInfo);
                if (label != null) appName = label.toString();
            }

            String report = "APK: " + appName +
                    "\nPackage: " + packageName +
                    "\nMinimum Android API: " + minSdk +
                    "\nTarget Android API: " + info.applicationInfo.targetSdkVersion +
                    "\nDevice API: " + Build.VERSION.SDK_INT +
                    "\n\n" + compatibilityMessage(info, minSdk);

            apkReport.setText(report);
            Button install = button("CONTINUE TO ANDROID INSTALLER");
            install.setOnClickListener(v -> launchInstaller(uri));
            content.addView(install, content.indexOfChild(apkReport) + 1);
        } catch (Exception e) {
            apkReport.setText("Could not inspect this APK: " + e.getMessage());
        } finally {
            if (temp != null) temp.delete();
        }
    }

    private String compatibilityMessage(PackageInfo info, String minSdk) {
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                int required = info.applicationInfo.minSdkVersion;
                if (Build.VERSION.SDK_INT < required) {
                    return "RESULT: This APK requires a newer Android API. ADB/Shizuku cannot add that missing Android platform version.";
                }
                return "RESULT: The declared minimum Android API is not higher than this device's API. Other requirements (CPU, GPU, features, signature, or app policy) may still prevent installation or launch.";
            } catch (Exception ignored) { }
        }
        return "RESULT: Minimum API could not be read reliably on this Android version. Let Android's package installer perform the final compatibility check.";
    }

    private void launchInstaller(Uri uri) {
        Intent install = new Intent(Intent.ACTION_VIEW);
        install.setDataAndType(uri, "application/vnd.android.package-archive");
        install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(install);
        } catch (Exception e) {
            toast("Android could not open the package installer.");
        }
    }

    private String getAbiList() {
        StringBuilder result = new StringBuilder();
        String[] abis = Build.SUPPORTED_ABIS;
        for (int i = 0; i < abis.length; i++) {
            if (i > 0) result.append(", ");
            result.append(abis[i]);
        }
        return result.length() == 0 ? Build.CPU_ABI : result.toString();
    }

    private void addCard(String title, String body) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(13), dp(15), dp(15));
        card.setBackgroundColor(PANEL);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, 0, 0, dp(13));
        content.addView(card, params);

        TextView heading = text(title, 12, PURPLE, true);
        card.addView(heading);
        TextView detail = text(body, 14, WHITE, false);
        detail.setPadding(0, dp(9), 0, 0);
        card.addView(detail);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(112, 55, 190)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(50));
        p.setMargins(0, 0, 0, dp(12));
        b.setLayoutParams(p);
        return b;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_LONG).show();
    }
}
