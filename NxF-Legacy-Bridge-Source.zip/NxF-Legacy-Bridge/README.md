# NxF Legacy Bridge V1

A purple-themed Android compatibility checker for Android 5.1 (API 22) through Android 16.

## What it does
- Shows Android version, device model, and CPU ABIs.
- Explains which Shizuku startup path applies to the current Android version.
- Opens the installed Shizuku app when available.
- Lets the user select an APK, reads package metadata, and reports the declared minimum API when available.
- Hands installation to Android's normal package installer.

## Important limitations
- This project does not bypass Android's minimum-SDK, CPU, GPU, signature, or hardware checks.
- Shizuku requires Android 6.0 or newer. Android 5.1 can run NxF diagnostics but cannot run Shizuku.
- Shizuku's built-in Wireless Debugging startup is Android 11+. Android 6–10 require starting Shizuku through ADB from a computer.
- The app does not contain Shizuku's code and does not request privileged shell access. It only detects/opens the official Shizuku app and provides setup guidance.
- Use APKs only from the app developer's official distribution channel. The system installer makes the final decision.

## Build with GitHub Actions
1. Upload this project to a GitHub repository.
2. Open **Actions**.
3. Run **Build NxF Legacy Bridge APK** (or push to `main`).
4. Download the `NxF-Legacy-Bridge-APK` artifact.
5. Extract the ZIP and install `app-debug.apk`.

## Local build
Requires JDK 17 and Gradle 8.13:
```bash
gradle assembleDebug
```
The APK is created at:
`app/build/outputs/apk/debug/app-debug.apk`
